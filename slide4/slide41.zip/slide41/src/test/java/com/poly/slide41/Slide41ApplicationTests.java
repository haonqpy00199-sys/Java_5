package com.poly.slide41;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Slide41ApplicationTests {

	@Test
	void contextLoads() {
	}

}
