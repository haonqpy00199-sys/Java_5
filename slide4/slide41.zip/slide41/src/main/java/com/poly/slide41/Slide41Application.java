package com.poly.slide41;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Slide41Application {

	public static void main(String[] args) {
		SpringApplication.run(Slide41Application.class, args);
	}

}
